package com.example.career_analyser

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
