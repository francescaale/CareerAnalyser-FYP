import 'package:flutter/material.dart'; // Import Flutter's Material Design components (UI widgets, themes, etc.)
import 'home.dart'; // Import your custom HomeScreen file

void main() { // Entry point of the Flutter application
  runApp(const CareerApp()); // Launch the app and start with CareerApp widget
}

class CareerApp extends StatelessWidget { // Define main app widget as stateless (no internal state changes)
  const CareerApp({super.key}); // Constructor with optional key for widget identification

  @override
  Widget build(BuildContext context) { // Build method describes how the UI should look
    return MaterialApp( // Root widget for the app, provides navigation, theme, etc.
      debugShowCheckedModeBanner: false, // Remove the debug banner in the top-right corner - https://api.flutter.dev/flutter/material/MaterialApp/debugShowCheckedModeBanner.html
      title: "Career Path Analysis", // App title (used by OS/task switcher)
      theme: ThemeData( // Define the global theme for the app - https://api.flutter.dev/flutter/material/ThemeData-class.html
        useMaterial3: true, // Enable Material Design 3 (modern UI system)
        colorSchemeSeed: const Color(0xFF6D63BC), // Generate app color scheme based on this seed color
      ),
      home: const HomeScreen(), // Set the first screen shown when app starts
    );
  }
}