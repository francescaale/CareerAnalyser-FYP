import 'package:flutter/material.dart'; // Import Flutter UI framework
import 'results.dart'; // Import results screen

// List of available careers - https://docs.flutter.dev/cookbook/lists/long-lists
const List<String> careers = [
  "App Developer",
  "Data Analyst",
  "UX Designer",
  "Software Developer",
  "Cybersecurity Analyst",
  "Web Developer",
];

// Map each career to its required skills - https://stackoverflow.com/questions/73174914/how-to-access-the-string-inside-the-list-in-mapstring-liststring
const Map<String, List<String>> careerSkillMap = {
  "App Developer": [
    "Dart","Flutter","Java","Kotlin","Swift","REST APIs","JSON","Git",
    "Firebase","UI/UX Basics","Debugging","Unit Testing","Problem Solving","Teamwork",
  ],
  "Data Analyst": [
    "Python","SQL","Excel","Power BI","Tableau","Data Cleaning",
    "Data Visualization","Statistics","Reporting","Dashboard Design",
  ],
  "UX Designer": [
    "UX Research","Wireframing","Prototyping","User Interviews",
    "Usability Testing","Information Architecture","Design Thinking",
    "Interaction Design","Accessibility","Figma",
  ],
  "Software Developer": [
    "Python","Java","C#","JavaScript","Algorithms","Data Structures",
    "Software Design","Testing","Debugging","Version Control",
  ],
  "Cybersecurity Analyst": [
    "Networking","Security Fundamentals","Threat Analysis",
    "Vulnerability Assessment","SIEM Tools","Firewalls","Linux",
    "Bash","Incident Response","Risk Management",
  ],
  "Web Developer": [
    "HTML","CSS","JavaScript","Responsive Design","React",
    "Node.js","PHP","Testing","Web Accessibility","SEO Basics",
  ],
};

class CareerSkillsScreen extends StatefulWidget { // Screen with state (changes based on user input)
  const CareerSkillsScreen({super.key});

  @override
  State<CareerSkillsScreen> createState() => _CareerSkillsScreenState();
}

class _CareerSkillsScreenState extends State<CareerSkillsScreen> {
  String? selectedCareer; // Stores selected career
  final Set<String> selectedSkills = {}; // Stores selected skills

  @override
  Widget build(BuildContext context) {

    // Get skills for selected career
    final currentSkills = selectedCareer == null
        ? []
        : careerSkillMap[selectedCareer!] ?? [];

    return Scaffold(
      backgroundColor: const Color(0xFFF6F7FB), // Page background

      appBar: AppBar( // Top app bar https://api.flutter.dev/flutter/material/AppBar-class.html
        backgroundColor: const Color(0xFFE9ECF2),
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "Choose Your Path",
          style: TextStyle(
            color: Color(0xFF6D63BC),
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24), // Page padding
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, //https://api.flutter.dev/flutter/rendering/CrossAxisAlignment.html
            children: [

              const SizedBox(height: 20),

              const Text( // Career label
                "Select a Career",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF2F3A45),
                ),
              ),
              const SizedBox(height: 10),

              Container( // Dropdown container
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.black12),
                ),
                child: DropdownButtonHideUnderline( //https://api.flutter.dev/flutter/material/DropdownButton-class.html
                  child: DropdownButton<String>(
                    value: selectedCareer,
                    hint: const Text("Choose a career"),
                    items: careers.map((career) { // Build dropdown items
                      return DropdownMenuItem(
                        value: career,
                        child: Text(career),
                      );
                    }).toList(),
                    onChanged: (value) { // When career changes
                      setState(() {
                        selectedCareer = value;
                        selectedSkills.clear(); // Reset skills
                      });
                    },
                  ),
                ),
              ),

              const SizedBox(height: 28),

              const Text( // Skills label
                "Select Your Skills",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF2F3A45),
                ),
              ),
              const SizedBox(height: 10),

              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.black12),
                  ),

                  // If no career selected
                  child: selectedCareer == null
                      ? const Center(
                    child: Text(
                      "Choose a career first.",
                      style: TextStyle(color: Colors.grey),
                    ),
                  )

                  // Show skill list
                      : ListView(
                    children: currentSkills.map((skill) {
                      final isSelected = selectedSkills.contains(skill);

                      return _SkillTile( // Custom skill widget
                        skill: skill,
                        selected: isSelected,
                        onTap: () {
                          setState(() {
                            isSelected
                                ? selectedSkills.remove(skill) // Remove
                                : selectedSkills.add(skill);   // Add
                          });
                        },
                      );
                    }).toList(),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              SizedBox(
                width: double.infinity,
                child: FilledButton( // CTA button https://api.flutter.dev/flutter/material/FilledButton-class.html
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    backgroundColor: const Color(0xFF6D63BC),
                  ),
                  onPressed: selectedCareer == null
                      ? null // Disabled if no career
                      : () {
                    Navigator.push( // Navigate to results
                      context,
                      MaterialPageRoute(
                        builder: (_) => ResultsScreen(
                          careerName: selectedCareer!,
                          selectedSkills: selectedSkills.toList(),
                        ),
                      ),
                    );
                  },
                  child: const Text(
                    "View Results",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}

// Reusable widget for each skill item https://api.flutter.dev/flutter/widgets/StatelessWidget-class.html
class _SkillTile extends StatelessWidget {
  final String skill; // Skill name
  final bool selected; // Whether it's selected
  final VoidCallback onTap; // Click action

  const _SkillTile({
    required this.skill,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell( // Clickable wrapper https://api.flutter.dev/flutter/material/InkWell-class.html
      borderRadius: BorderRadius.circular(10),
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: selected
              ? const Color(0xFF6D63BC).withOpacity(0.15) // Highlight selected
              : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: selected ? const Color(0xFF6D63BC) : Colors.black12,
            width: selected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.check_circle : Icons.circle_outlined, // Icon changes
              color: selected ? const Color(0xFF6D63BC) : Colors.grey,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                skill,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: selected
                      ? const Color(0xFF4F45A6)
                      : Colors.black87,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}