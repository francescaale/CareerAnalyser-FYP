import 'package:flutter/material.dart'; // Import Flutter Material UI components
import 'career_skills.dart'; // Import the CareerSkillsScreen page

class HomeScreen extends StatelessWidget { // Define HomeScreen as a stateless widget
  const HomeScreen({super.key}); // Constructor

  @override
  Widget build(BuildContext context) { // Build UI
    return Scaffold( // Main page structure
      backgroundColor: const Color(0xFFF6F7FB), // Page background color
      body: SafeArea( // Prevent overlap with system UI
        child: Column( // Vertical layout
          children: [

            Container( // Top hero section
              width: double.infinity, // Full width
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 40), // Padding
              decoration: const BoxDecoration(
                color: Color(0xFFE9ECF2), // Background color
                borderRadius: BorderRadius.only( // Rounded bottom corners
                  bottomLeft: Radius.circular(28),
                  bottomRight: Radius.circular(28),
                ),
              ),
              child: Column(
                children: const [
                  Text( // Main title
                    "Find Your Skills.\nBridge the Gap.\nShape Your Future.",
                    textAlign: TextAlign.center, // Center text
                    style: TextStyle(
                      fontSize: 26, // Font size
                      fontWeight: FontWeight.w800, // Bold
                      height: 1.25, // Line height
                      color: Color(0xFF6D63BC), // Text color
                    ),
                  ),
                  SizedBox(height: 12), // Space
                  Text( // Subtitle
                    "A simple way to understand where you stand\nand what you need next.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 14,
                      height: 1.5,
                      color: Color(0xFF4A4F57),
                    ),
                  ),
                ],
              ),
            ),

            Expanded( // Fill remaining space https://api.flutter.dev/flutter/widgets/Expanded-class.html
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28), // Side padding
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center, // Center content vertically
                  children: [
                    const Text( // Section title
                      "Why It Matters",
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF2F3A45),
                      ),
                    ),
                    const SizedBox(height: 12), // Space
                    Text( // Description
                      "Choose a career goal, select your current skills,\nand instantly see where you match and what’s missing.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        height: 1.5,
                        color: Colors.grey.shade700,
                      ),
                    ),

                    const SizedBox(height: 40), // Space before button

                    SizedBox(
                      width: double.infinity, // Full width button
                      child: FilledButton(
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16), // Button padding
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12), // Rounded corners
                          ),
                          backgroundColor: const Color(0xFF6D63BC), // Button color
                        ),
                        onPressed: () { // On click action
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const CareerSkillsScreen(), // Navigate to next screen
                            ),
                          );
                        },
                        child: const Text( // Button text
                          "Start Your Analysis",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20), // Bottom spacing
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}