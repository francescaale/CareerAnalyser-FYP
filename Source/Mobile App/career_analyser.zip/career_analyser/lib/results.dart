import 'package:flutter/material.dart'; // Import Flutter Material UI package
import 'package:fl_chart/fl_chart.dart'; // Import chart package for bar charts
import 'package:share_plus/share_plus.dart'; // Import sharing package
import 'career_skills.dart'; // Import career skills data

class ResultsScreen extends StatelessWidget { // Results screen widget
  final String careerName; // Selected career name
  final List<String> selectedSkills; // Skills selected by the user

  const ResultsScreen({ // Constructor
    super.key, // Optional widget key
    required this.careerName, // Require career name
    required this.selectedSkills, // Require selected skills
  });

  List<String> _requiredSkillsForCareer(String career) { // Get required skills for a career
    return careerSkillMap[career] ?? ["Teamwork", "Problem Solving"]; // Return mapped skills or fallback skills
  }

  List<double> _yourSkillValues() { // Create chart values for user's selected skills
    return List<double>.filled(selectedSkills.length, 100); // Give each selected skill a value of 100
  }

  String _shareText() { // Build text used for sharing results - https://pub.dev/packages/share_plus
    final required = _requiredSkillsForCareer(careerName); // Get required skills for selected career
    final missing = required // Start filtering missing skills
        .where((r) => !selectedSkills.map((s) => s.toLowerCase()).contains(r.toLowerCase())) // Keep only skills not selected by user https://api.flutter.dev/flutter/dart-core/Iterable/where.html
        .toList(); // Convert result to list

    return "Career Path Analyser Results\n" // First line of shared text
        "Career: $careerName\n" // Career name line
        "My skills: ${selectedSkills.isEmpty ? "None" : selectedSkills.join(", ")}\n" // Selected skills line
        "Skills on demand: ${required.join(", ")}\n" // Required skills line
        "Missing: ${missing.isEmpty ? "None" : missing.join(", ")}\n"; // Missing skills line
  }

  Future<void> _shareInstagram(BuildContext context) async { // Share results https://pub.dev/documentation/share_plus/latest/share_plus/Share-class.html
    await Share.share(_shareText(), subject: "My Career Results"); // Open share sheet with results text // reference https://pub.dev/packages/share_plus
  }

  @override
  Widget build(BuildContext context) { // Build screen UI
    final requiredSkills = _requiredSkillsForCareer(careerName); // Get required skills for current career

    final selectedLower = selectedSkills.map((e) => e.toLowerCase()).toList(); // Convert selected skills to lowercase for comparison
    final matched = requiredSkills.where((r) => selectedLower.contains(r.toLowerCase())).toList(); // Skills the user has that match requirements https://api.flutter.dev/flutter/dart-core/Iterable/where.html
    final missing = requiredSkills.where((r) => !selectedLower.contains(r.toLowerCase())).toList(); // Skills the user is missing https://api.flutter.dev/flutter/dart-core/Iterable/where.html

    final limitedMissing = missing.take(3).toList(); // Take only first 3 missing skills for chart display
    final displaySkills = [...matched, ...limitedMissing]; // Combine matched skills and limited missing skills

    final demandLabels = displaySkills; // Labels for career demand chart
    final demandValues = displaySkills.map((s) => matched.contains(s) ? 100.0 : 0.0).toList(); // Use 100 for matched, 0 for missing
    final demandIsMatched = displaySkills.map((s) => matched.contains(s)).toList(); // Track whether each displayed skill is matched

    return Scaffold( // Main page structure
      backgroundColor: const Color(0xFFF6F7FB), // Page background color
      appBar: AppBar( // Top app bar https://api.flutter.dev/flutter/material/AppBar-class.html
        backgroundColor: const Color(0xFFE9ECF2), // App bar background color
        elevation: 0, // Remove shadow
        centerTitle: true, // Center app bar title
        title: const Text( // App bar title text
          "Your Results",
          style: TextStyle(
            color: Color(0xFF6D63BC), // Title color
            fontWeight: FontWeight.w700, // Title weight
          ),
        ),
      ),

      body: SingleChildScrollView( // Allow vertical scrolling https://api.flutter.dev/flutter/widgets/SingleChildScrollView-class.html
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20), // Page padding
        child: Column( // Vertical layout
          crossAxisAlignment: CrossAxisAlignment.start, // Align children to start horizontally
          children: [

            Container( // Hero card
              width: double.infinity, // Full width
              padding: const EdgeInsets.all(18), // Inner padding
              decoration: BoxDecoration( //https://api.flutter.dev/flutter/painting/BoxDecoration-class.html
                color: const Color(0xFFF3F2FF), // Background color
                borderRadius: BorderRadius.circular(16), // Rounded corners https://api.flutter.dev/flutter/painting/BorderRadius-class.html
                border: Border.all(color: const Color(0xFFD9D6FF)), // Border color
              ),
              child: Column( // Hero card content layout
                crossAxisAlignment: CrossAxisAlignment.start, // Left align text
                children: [
                  Text( // Career title
                    careerName,
                    style: const TextStyle(
                      fontSize: 22, // Font size
                      fontWeight: FontWeight.w800, // Font weight
                      color: Color(0xFF4F45A6), // Text color
                    ),
                  ),
                  const SizedBox(height: 8), // Space below title
                  Text( // User skills summary
                    selectedSkills.isEmpty
                        ? "No skills selected." // Fallback if none selected
                        : "Your skills: ${selectedSkills.join(", ")}", // Show selected skills
                    style: const TextStyle(fontSize: 14), // Text style
                  ),
                ],
              ),
            ),

            const SizedBox(height: 28), // Space after hero card

            const Text( // Section title for user skills
              "Your Skills",
              style: TextStyle(
                fontSize: 18, // Font size
                fontWeight: FontWeight.w800, // Font weight
                color: Color(0xFF2F3A45), // Text color
              ),
            ),
            const SizedBox(height: 12), // Space before chart

            _ChartCard( // Wrapper card for first chart
              height: 300, // Card height
              child: SimpleBarChart( // Bar chart showing selected skills https://pub.dev/documentation/fl_chart/latest/fl_chart/BarChartData-class.html
                values: _yourSkillValues(), // Values for user's skills
                labels: selectedSkills, // Labels for user's skills
                emptyText: "No selected skills yet.", // Empty chart message
              ),
            ),

            const SizedBox(height: 32), // Space after first chart

            const Text( // Section title for matched skills chart
              "Matched Skills (Based on Your Career)",
              style: TextStyle(
                fontSize: 18, // Font size
                fontWeight: FontWeight.w800, // Font weight
                color: Color(0xFF2F3A45), // Text color
              ),
            ),
            const SizedBox(height: 12), // Space before second chart

            _ChartCard( // Wrapper card for second chart
              height: 300, // Card height
              child: SimpleBarChart( // Bar chart showing matched and missing skills https://pub.dev/documentation/fl_chart/latest/fl_chart/BarChartData-class.html
                values: demandValues, // Chart values
                labels: demandLabels, // Chart labels
                emptyText: "No career skills found.", // Empty chart message
                matchedFlags: demandIsMatched, // Marks which bars are matched
              ),
            ),

            const SizedBox(height: 32), // Space after second chart

            _SummaryCard(required: requiredSkills, selected: selectedSkills), // Summary card with matched and missing skills

            const SizedBox(height: 32), // Space after summary

            Container( // Share card
              padding: const EdgeInsets.all(16), // Inner padding
              decoration: BoxDecoration( //https://api.flutter.dev/flutter/painting/BoxDecoration-class.html
                color: Colors.white, // Background color
                borderRadius: BorderRadius.circular(16), // Rounded corners https://api.flutter.dev/flutter/painting/BorderRadius-class.html
                border: Border.all(color: Colors.black12), // Border color
              ),
              child: Column( // Share card layout
                crossAxisAlignment: CrossAxisAlignment.start, // Left align content
                children: [
                  const Text( // Share section title
                    "Share your results",
                    style: TextStyle(
                      fontSize: 16, // Font size
                      fontWeight: FontWeight.w800, // Font weight
                    ),
                  ),
                  const SizedBox(height: 14), // Space below title
                  Row( // Row of share buttons
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly, // Even spacing
                    children: [
                      _SocialIconButton( // Instagram-style share button https://api.flutter.dev/flutter/widgets/Icon-class.html
                        label: "Instagram", // Button label
                        icon: Icons.camera_alt, // Button icon https://api.flutter.dev/flutter/material/Icons/camera_alt-constant.html
                        onTap: () => _shareInstagram(context), // Share action
                      ),
                      _SocialIconButton( // Facebook share button https://api.flutter.dev/flutter/widgets/Icon-class.html
                        label: "Facebook",
                        icon: Icons.facebook, //https://api.flutter.dev/flutter/material/Icons/facebook-constant.html
                        onTap: () => Share.share(_shareText()), // Share action
                      ),
                      _SocialIconButton( // LinkedIn share button https://api.flutter.dev/flutter/widgets/Icon-class.html
                        label: "LinkedIn",
                        icon: Icons.work, //https://api.flutter.dev/flutter/material/Icons-class.html
                        onTap: () => Share.share(_shareText()), // Share action
                      ),
                      _SocialIconButton( // Generic share button https://api.flutter.dev/flutter/widgets/Icon-class.html
                        label: "More",
                        icon: Icons.share, //https://api.flutter.dev/flutter/material/Icons-class.html
                        onTap: () => Share.share(_shareText()), // Share action
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 40), // Bottom spacing
          ],
        ),
      ),
    );
  }
}

class _ChartCard extends StatelessWidget { // Small reusable card widget for charts
  final double height; // Card height
  final Widget child; // Widget displayed inside the card

  const _ChartCard({required this.height, required this.child}); // Constructor

  @override
  Widget build(BuildContext context) { // Build chart card UI
    return Container(
      height: height, // Set fixed height
      padding: const EdgeInsets.all(14), // Inner padding
      decoration: BoxDecoration( //https://api.flutter.dev/flutter/painting/BoxDecoration-class.html
        color: Colors.white, // Background color
        borderRadius: BorderRadius.circular(16), // Rounded corners https://api.flutter.dev/flutter/painting/BorderRadius-class.html
        border: Border.all(color: Colors.black12), // Border color
      ),
      child: child, // Place child widget inside
    );
  }
}

class _SummaryCard extends StatelessWidget { // Summary card widget
  final List<String> required; // Required skills list
  final List<String> selected; // Selected skills list

  const _SummaryCard({required this.required, required this.selected}); // Constructor

  @override
  Widget build(BuildContext context) { // Build summary card UI
    final selectedLower = selected.map((e) => e.toLowerCase()).toList(); // Lowercase selected skills for comparison
    final matched = required.where((r) => selectedLower.contains(r.toLowerCase())).toList(); // Matched skills list https://api.flutter.dev/flutter/dart-core/Iterable/where.html
    final missing = required.where((r) => !selectedLower.contains(r.toLowerCase())).toList(); // Missing skills list https://api.flutter.dev/flutter/dart-core/Iterable/where.html

    return Container(
      padding: const EdgeInsets.all(16), // Inner padding
      decoration: BoxDecoration( //https://api.flutter.dev/flutter/painting/BoxDecoration-class.html
        color: Colors.white, // Background color
        borderRadius: BorderRadius.circular(16), // Rounded corners https://api.flutter.dev/flutter/painting/BorderRadius-class.html
        border: Border.all(color: Colors.black12), // Border color
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start, // Left align content
        children: [
          const Text( // Summary title
            "Summary",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12), // Space below title

          Text( // Match count text
            "You match ${matched.length} out of ${required.length} skills",
            style: const TextStyle(
              fontSize: 15, // Font size
              fontWeight: FontWeight.w700, // Font weight
            ),
          ),

          const SizedBox(height: 12), // Space before details
          Text("Matched: ${matched.isEmpty ? "None" : matched.join(", ")}"), // Show matched skills
          const SizedBox(height: 6), // Space between matched and missing
          Text("Missing: ${missing.isEmpty ? "None" : missing.join(", ")}"), // Show missing skills
        ],
      ),
    );
  }
}

class _SocialIconButton extends StatelessWidget { // Small reusable social/share button
  final String label; // Button text label
  final IconData icon; // Button icon https://api.flutter.dev/flutter/widgets/Icon-class.html
  final VoidCallback onTap; // Tap action

  const _SocialIconButton({ // Constructor
    required this.label, // Require label
    required this.icon, // Require icon https://api.flutter.dev/flutter/widgets/Icon-class.html
    required this.onTap, // Require tap action
  });

  @override
  Widget build(BuildContext context) { // Build social button UI
    return InkWell( //https://api.flutter.dev/flutter/material/InkWell-class.html
      borderRadius: BorderRadius.circular(12), // Ripple shape https://api.flutter.dev/flutter/painting/BorderRadius-class.html
      onTap: onTap, // Run action on tap
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10), // Inner padding
        child: Column(
          children: [
            Icon(icon, size: 28, color: const Color(0xFF6D63BC)), // Icon display
            const SizedBox(height: 4), // Space below icon
            Text(label, style: const TextStyle(fontSize: 12)), // Label text
          ],
        ),
      ),
    );
  }
}

class SimpleBarChart extends StatelessWidget { // Reusable bar chart widget
  final List<double> values; // Numeric bar values
  final List<String> labels; // Labels under bars
  final String emptyText; // Message shown if chart has no data
  final List<bool>? matchedFlags; // Optional list showing whether each bar is matched

  const SimpleBarChart({ // Constructor
    super.key, // Optional widget key
    required this.values, // Require values
    required this.labels, // Require labels
    required this.emptyText, // Require empty text
    this.matchedFlags, // Optional matched flags
  });

  @override
  Widget build(BuildContext context) { // Build chart UI
    if (values.isEmpty || labels.isEmpty) { // Check if there is no data
      return Center(child: Text(emptyText)); // Show fallback message
    }

    final baseFill = const Color(0xFF6D63BC).withOpacity(0.30); // Default bar fill color
    final baseBorder = const Color(0xFF6D63BC); // Default bar border color

    return BarChart(
      BarChartData( //https://pub.dev/documentation/fl_chart/latest/fl_chart/BarChartData-class.html
        maxY: 100, // Maximum Y-axis value
        groupsSpace: 24, // Space between bar groups
        gridData: const FlGridData(show: true), // Show chart grid
        borderData: FlBorderData(show: false), // Hide outer border
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)), // Hide top titles
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)), // Hide right titles

          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true, // Show left axis titles
              interval: 20, // Show values every 20
              getTitlesWidget: (value, meta) { // Build each left title
                return Text(value.toInt().toString(), style: const TextStyle(fontSize: 10)); // Show value as text
              },
            ),
          ),

          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true, // Show bottom labels
              reservedSize: 70, // Reserve extra space for rotated labels
              getTitlesWidget: (value, meta) { // Build each bottom label
                final int i = value.toInt(); // Convert position to list index
                if (i < 0 || i >= labels.length) return const SizedBox.shrink(); // Return empty widget if out of range

                return Transform.rotate(
                  angle: -0.6, // Rotate labels to fit
                  child: SizedBox(
                    width: 80, // Label width
                    child: Text(
                      labels[i], // Current label text
                      textAlign: TextAlign.right, // Right align rotated text
                      style: const TextStyle(
                        fontSize: 11, // Font size
                        fontWeight: FontWeight.bold, // Bold font
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),

        barGroups: List.generate(values.length, (i) { // Create one bar group for each value - https://api.flutter.dev/flutter/dart-core/List/List.generate.html
          final isMatched = matchedFlags != null && matchedFlags![i]; // Check if this bar represents a matched skill

          final missingGradient = LinearGradient(
            colors: [
              const Color(0xFF6D63BC).withOpacity(0.25), // Gradient start
              Colors.transparent, // Gradient middle
              const Color(0xFF6D63BC).withOpacity(0.25), // Gradient end
            ],
            begin: Alignment.topCenter, // Gradient start alignment
            end: Alignment.bottomCenter, // Gradient end alignment
          );

          return BarChartGroupData( //https://pub.dev/documentation/fl_chart/latest/fl_chart/BarChartGroupData-class.html
            x: i, // X position of this group
            barRods: [
              BarChartRodData( //https://pub.dev/documentation/fl_chart/latest/fl_chart/BarChartRodData-class.html
                toY: values[i], // Height of the bar
                width: 14, // Bar width
                borderRadius: BorderRadius.circular(8), // Rounded bar corners https://api.flutter.dev/flutter/painting/BorderRadius-class.html
                color: matchedFlags == null
                    ? baseFill // Use default fill if no matched flags are provided
                    : (isMatched ? baseFill : null), // Use fill only for matched bars
                gradient: matchedFlags == null
                    ? null // No gradient for normal chart
                    : (isMatched ? null : missingGradient), // Use striped gradient for missing bars
                borderSide: BorderSide(
                  color: matchedFlags == null
                      ? baseBorder // Default border color
                      : (isMatched ? baseBorder : baseBorder.withOpacity(0.4)), // Lighter border for missing bars
                  width: 2, // Border width
                ),
              ),
            ],
          );
        }),
      ),
    );
  }
}